-- [SQL Server] CRUD
-- Aula 10 de 21 - UPDATE - Atualizando o dado de uma tabela

-- Crie uma tabela chamada 'Produtos'
-- Essa abela deve conter 4 colunas: id_produt, nome_produto, data_validade e preco_produto
-- Certifique-se de que o tipo das colunas est� correto.

CREATE DATABASE BDImpressionador    -- Obs: Se voc� j� criou o BD Impressionador n�o precisa executar esta linha

USE BDImpressionador

CREATE TABLE Produtos(
	id_produto INT,
	nome_produto VARCHAR(200),
	data_validade DATETIME,
	preco_produto FLOAT
)

SELECT * FROM Produtos

-- Adicionando valores de outra tabela

INSERT INTO Produtos(id_produto, nome_produto, data_validade, preco_produto)
SELECT
	ProductKey,
	ProductName,
	AvailableForSaleDate,
	UnitPrice
FROM
	ContosoRetailDW.dbo.DimProduct

-- Adicionando novos valores na tabela

INSERT INTO Produtos(id_produto, nome_produto, data_validade, preco_produto)
VALUES
	(1, 'Arroz', '2021-12-31', 22.50),
	(2, 'Feij�o', '2021-12-31', 8.99)

-- Atualizando o dado de uma tabela

UPDATE Produtos
SET nome_produto = 'Macarr�o'
WHERE id_produto = 3
