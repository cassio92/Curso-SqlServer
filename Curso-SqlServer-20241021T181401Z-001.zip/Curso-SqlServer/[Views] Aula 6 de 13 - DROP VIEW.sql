-- [SQL Server] Views
-- Aula 6 de 13: DROP VIEW


-- Exemplo: Exclua as views vwClientes e vwProdutos


DROP VIEW vwProdutos
DROP VIEW vwClientes