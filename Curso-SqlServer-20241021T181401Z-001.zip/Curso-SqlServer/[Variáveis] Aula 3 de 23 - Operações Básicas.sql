-- [SQL Server] Vari�veis
-- Aula 3 de 23: Opera��es B�sicas

-- Opera��es b�sicas

SELECT 10 AS 'N�mero'

SELECT 'Marcus' AS 'Nome'

SELECT '21/06/2021' AS 'Data'

-- Opera��es com n�meros

SELECT 10+20
SELECT 20-5
SELECT 31*40
SELECT 431.0/23

-- Opera��es com textos

SELECT 'SQL' + ' ' + 'Impressionador'

-- Opera��es com datas

SELECT '21/03/2021' + 1
