-- [SQL Server] Vari�veis
-- Aula 7 de 23: ROUND, FLOOR e CEILING - Fun��es de Arredondamento

-- Opera��es com n�meros

SELECT 10+20
SELECT 20-5
SELECT 31*40
SELECT 431.0/23

-- ROUND

SELECT ROUND(18.739130, 2)

-- ROUND (Truncar)

SELECT ROUND(18.739130, 2, 1)

-- FLOOR

SELECT FLOOR(18.739130)

-- CEILING

SELECT CEILING(18.739130)
