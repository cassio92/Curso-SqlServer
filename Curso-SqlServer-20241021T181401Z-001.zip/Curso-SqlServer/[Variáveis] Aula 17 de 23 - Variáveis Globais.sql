-- [SQL Server] Vari�veis
-- Aula 17 de 23: Vari�veis Globais


SELECT @@SERVERNAME

SELECT @@VERSION


SELECT * FROM DimProduct
SELECT @@ROWCOUNT
