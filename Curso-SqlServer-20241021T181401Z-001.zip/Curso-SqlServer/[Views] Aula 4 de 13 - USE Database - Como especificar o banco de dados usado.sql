-- [SQL Server] Views
-- Aula 4 de 13: USE Database - Como especificar o banco de dados usado

USE Teste
SELECT * FROM Produtos

USE ContosoRetailDW
SELECT * FROM DimProduct